﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace krOS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
        }

        private static void DeleteDirectory(string targetDir)
        {
            /*string[] files = Directory.GetFiles(targetDir);
            foreach (string file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }
            string[] dirs = Directory.GetDirectories(targetDir);
            foreach (string dir in dirs)
            {
                DeleteDirectory(dir);
            }
            Directory.Delete(targetDir, false);
            string folderPath = "путь к папке";
            DeleteDirectory(folderPath);
            Console.WriteLine("Папка успешно удалена");*/
            var dir = new DirectoryInfo(targetDir);
            if (dir.Exists) { dir.Delete(); }  
        }
        private void btnOpen_Click(object sender, EventArgs e)
        {
                using (FolderBrowserDialog fbd = new FolderBrowserDialog() { Description = "Select your path." })
                {
                    if (fbd.ShowDialog() == DialogResult.OK)
                    {
                        webBrowser.Url = new Uri(fbd.SelectedPath);
                        txtPath.Text = fbd.SelectedPath;
                    }
                }
        }
    }
}
